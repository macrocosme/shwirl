External resources
------------------

This directory contains a bundled version of VisPy. We include the
latest developer version (0.5.0.dev0) to avoid the need for users 
to install it themselves. Moreover, some modifications have been done
relative to color maps and color bars. The license for VisPy is 
provided in VISPY_LICENSE contained within this directory.
