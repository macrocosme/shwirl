def main():
    from shwirl import main
    main()